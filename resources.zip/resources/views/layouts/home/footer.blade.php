<footer id="footer" class="footer-wrapper"></footer>
<section class="section tin-khuyen-mai" id="section_497818777">
    <div class="bg section-bg fill bg-fill   bg-loaded"></div>
    <div class="section-content relative">
        <div class="row row-large" id="row-638417439">
            <div class="col cot1 medium-6 small-12 large-6">
                <div class="col-inner">
                    <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_915562039">
                        <div class="img-inner dark">
                            <img width="550" height="157" src="{{asset('/home/custom/images/banner_newsletter.png')}}"
                                class="attachment-original size-original lazyloaded" alt=""
                                sizes="(max-width: 550px) 100vw, 550px" data-was-processed="true">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col cot2 medium-6 small-12 large-6">
                <div class="col-inner">
                    <div class="gap-element clearfix" style="display:block; height:auto; padding-top:44px"></div>
                    <div role="form" class="wpcf7" id="wpcf7-f687-o1" lang="vi" dir="ltr">
                        <div class="screen-reader-response"></div>
                        <!-- <form action="/danh-muc/khan-lanh-mang-ghep/#wpcf7-f687-o1" method="post" class="wpcf7-form"
                            novalidate="novalidate">
                            <div style="display: none;"> <input type="hidden" name="_wpcf7" value="687"> <input
                                    type="hidden" name="_wpcf7_version" value="5.1.4"> <input type="hidden"
                                    name="_wpcf7_locale" value="vi"> <input type="hidden" name="_wpcf7_unit_tag"
                                    value="wpcf7-f687-o1"> <input type="hidden" name="_wpcf7_container_post" value="0">
                            </div>
                            <div class="flex-row form-flat medium-flex-wrap">
                                <div class="flex-col flex-grow"> <span class="wpcf7-form-control-wrap your-email"><input
                                            type="email" name="your-email" value="" size="40"
                                            class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email"
                                            aria-required="true" aria-invalid="false"
                                            placeholder="Địa chỉ email (*)"></span></div>
                                <div class="flex-col ml-half"> <input type="submit" value="Đăng ký"
                                        class="wpcf7-form-control wpcf7-submit button"><span class="ajax-loader"></span>
                                </div>
                                <p></p>
                            </div>
                            <div class="wpcf7-response-output wpcf7-display-none"></div>
                        </form> -->
                    </div>
                </div>
            </div>
            <style scope="scope"></style>
        </div>
    </div>
    <style scope="scope">
    #section_497818777 {
        padding-top: 0;
        padding-bottom: 0
    }

    #section_497818777 .section-bg.bg-loaded {
        background-image: url('/home/custom/images/bg_footer.jpg')
    }
    </style>
</section>
<section class="section footer-section" id="section_1952211380">
    <div class="bg section-bg fill bg-fill  bg-loaded"></div>
    <div class="section-content relative">
        <div class="row row-small" id="row-742871302">
            <div class="col medium-6 small-12 large-6">
                <div class="col-inner">
                    <div class="row row-small" id="row-2007991889">
                        <div class="col gioi-thieu medium-6 small-12 large-6">
                            <div class="col-inner" style="padding:0px 0px 0 0px;margin:0px 0px 1p0x 0px;">
                                <h4><span style="font-size: 95%;"><strong>Giới thiệu</strong></span></h4>
                                <ul class="list-menu list-menu22">
                                    <li class="li_menu"><span style="font-size: 85%;"><a href="/gioi-thieu">Giới
                                                thiệu</a></span></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col gioi-thieu medium-6 small-12 large-6">
                            <div class="col-inner" style="padding:0px 0px 0 0px;margin:0px 0px 0 0px;">
                                <h4><span style="font-size: 95%;"><strong>Chính sách công ty</strong></span></h4>
                                <ul class="list-menu list-menu22">
                                    <li class="li_menu"><a href="/hinh-thuc-dat-hang"><span style="font-size: 85%;">Hình
                                                thức đặt hàng</span></a></li>
                                    <li class="li_menu"><a href="/hinh-thuc-thanh-toan/"><span
                                                style="font-size: 85%;">Hình thức thanh toán</span></a></li>
                                </ul>
                            </div>
                        </div>
                        <style scope="scope">
                        #row-2007991889>.col>.col-inner {
                            padding: 0 0 0 0
                        }
                        </style>
                    </div>
                    <div class="row row-small" id="row-1585558556">
                        <div class="col small-12 large-12">
                            <div class="col-inner" style="padding:0px 0px 0 0px;margin:0px 0px 0 0px;">
                                <h4><span style="font-size: 95%;"><strong>Bản đồ</strong></span></h4>
                                <p>
                                <div class="mapouter">
                                    <div class="gmap_canvas"><iframe width="779" height="305" id="gmap_canvas"
                                            src="https://maps.google.com/maps?q=147%2F25%20%C4%90%C6%B0%E1%BB%9Dng%20s%E1%BB%91%2015%2C%20B%C3%ACnh%20H%C6%B0ng%20H%C3%B2a%2C%20B%C3%ACnh%20T%C3%A2n%2C%20Th%C3%A0nh%20ph%E1%BB%91%20H%E1%BB%93%20Ch%C3%AD%20Minh&t=&z=15&ie=UTF8&iwloc=&output=embed"
                                            frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                                    </div>
                                    <style>
                                    .mapouter {
                                        position: relative;
                                        text-align: right;
                                        height: 100%;
                                        width: 100%;
                                    }

                                    .gmap_canvas {
                                        overflow: hidden;
                                        background: none !important;
                                        height: 100%;
                                        width: 100%;
                                    }
                                    </style>
                                </div>
                                </p>
                            </div>
                        </div>
                        <style scope="scope"></style>
                    </div>
                </div>
            </div>
            <div class="col medium-6 small-12 large-6">
                <div class="col-inner">
                    <div class="row row-small" id="row-478474249">
                        <div class="col medium-6 small-12 large-6">
                            <div class="col-inner">
                                <h4><span style="font-size: 95%;"><strong>Hotline liên hệ:</strong></span></h4>
                                <div class="icon-box featured-box icon-box-left text-left">
                                    <div class="icon-box-img" style="width: 60px">
                                        <div class="icon">
                                            <div class="icon-inner">
                                                <img width="53" height="40"
                                                    src="{{asset("/home/custom/images/phone.png")}}"
                                                    class="attachment-medium size-medium lazyloaded" alt=""
                                                    data-was-processed="true">
                                                <noscript>
                                                    <img width="53" height="40"
                                                        src="{{asset('/home/custom/images/phone.png')}}"
                                                        class="attachment-medium size-medium" alt="" />
                                                </noscript>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="icon-box-text last-reset">
                                        <p>
                                            <span style="color: #539414;">0315 762 650</span><br>
                                            <span style="color: #539414;"></span><br>
                                            <span style="color: #539414;"></span>
                                        </p>
                                    </div>
                                </div>
                                <div class="gap-element clearfix" style="display:block; height:auto; padding-top:20px">
                                </div>
                                <h4><span style="font-size: 95%;"><strong>Kết nối với chúng tôi</strong></span></h4>
                                <div id="fb-root" class=" fb_reset">
                                    <div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
                                        <div></div>
                                    </div>
                                </div>
                                <p>
                                    <script async="" defer="" crossorigin="anonymous"
                                        src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&amp;version=v3.3&amp;appId=254082782053411&amp;autoLogAppEvents=1">
                                    </script>
                                </p>
                                <!-- <div class="fb-page fb_iframe_widget"
                                    data-href="https://www.facebook.com/Khanlanhtoanphat/" data-tabs="timeline"
                                    data-width="300" data-height="200" data-small-header="false"
                                    data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"
                                    fb-xfbml-state="rendered"
                                    fb-iframe-plugin-query="adapt_container_width=true&amp;app_id=254082782053411&amp;container_width=245&amp;height=200&amp;hide_cover=false&amp;href=https%3A%2F%2Fwww.facebook.com%2FkhanlanhgiareOMI%2F&amp;locale=vi_VN&amp;sdk=joey&amp;show_facepile=true&amp;small_header=false&amp;tabs=timeline&amp;width=300">
                                    <span style="vertical-align: bottom; width: 245px; height: 200px;">
                                        <iframe name="f33aba2e1e06344" width="300px" height="200px"
                                            data-testid="fb:page Facebook Social Plugin"
                                            title="fb:page Facebook Social Plugin" frameborder="0"
                                            allowtransparency="true" allowfullscreen="true" scrolling="no"
                                            allow="encrypted-media" src="https://www.facebook.com/Khanlanhtoanphat/"
                                            style="border: none; visibility: visible; width: 245px; height: 200px;"
                                            class="">
                                        </iframe>
                                    </span>
                                </div> -->
                                <div class="fb-page" data-href="https://www.facebook.com/Khanlanhtoanphat/"
                                    data-width="380" data-hide-cover="false" data-show-facepile="false"></div>
                                <div class="gap-element clearfix" style="display:block; height:auto; padding-top:20px">
                                </div>
                            </div>
                        </div>
                        <div class="col medium-6 small-12 large-6">
                            <div class="col-inner">
                                <h4><span style="font-size: 95%;"><strong>Liên hệ</strong></span></h4>
                                <p>
                                    <strong>Địa chỉ</strong><br>
                                    <span style="font-size: 85%;">147/25 Đường 15, Khu Phố 10, Phường Bình Hưng Hòa,
                                        Quận Bình Tân, TP HCM</span>
                                </p>
                                <p> <strong>Điện thoại</strong></p>
                                <p><span style="font-size: 150%;color:red;">0315 762 650</span></p>
                                <p><strong>Email</strong></p>
                                <p><span style="font-size: 85%;">wunatoanphat@yahoo.com.vn</span></p>
                                <p><span style="font-size: 85%; color: #288f00;">Giờ mở hàng: 7:00-22:00 hàng
                                        ngày</span></p>
                            </div>
                        </div>
                        <style scope="scope"></style>
                    </div>
                </div>
            </div>
            <style scope="scope"></style>
        </div>
    </div>
    <style scope="scope">
    #section_1952211380 {
        padding-top: 30px;
        padding-bottom: 30px
    }
    </style>
</section>
<a href="javascript:void(0)" id="top" style="pointer-events: auto;" onclick="topFunction()" class="back-to-top button icon invert plain fixed bottom z-1 is-outline hide-for-medium circle"
    id="top-link">
    <i class="fa fa-arrow-up"></i>
</a>
</footer>
<script>
    //Get the button:
    mybutton = document.getElementById("top");
    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {scrollFunction()};
    function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.opacity = "1";
    } else {
        mybutton.style.opacity = "0";
    }
    }
    function topFunction() {
        document.body.scrollTop = 0; // For Safari
        document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
    }
</script>