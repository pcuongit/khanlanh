<div class="alert alert-danger alert-dismissible hidden" role="alert" id="errors">
    <button type="button" class="close" onClick="closeAlert(event)">
        <span aria-hidden="true">×</span>
    </button>
    <p class="msg">
    </p>
</div>
<div class="alert alert-success alert-dismissible hidden" role="alert" id="success">
    <button type="button" class="close" onClick="closeAlert(event)">
        <span aria-hidden="true">×</span>
    </button>
    <p class="msg">
    </p>
</div>